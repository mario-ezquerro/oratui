# 🚀 POC Multi-Servidor de Observabilidad y Operación Activa Oracle & Linux (`ora-tui v1.10.0` + Flutter Web Command & SRE Center + Prometheus + Grafana + Ansible + Jenkins)

Esta carpeta **`POC/`** proporciona una arquitectura integral de **Observabilidad, Ingeniería de Fiabilidad (SRE/SLO), Seguridad Sincronizada y Operación Remota Activa** para **1 o 100 servidores Oracle**:

1. **⚡ Contenedor `ORA-TUI Flutter Web Command & SRE Center` (`:8088`, en [`POC/flutter-web/`](file:///Users/mario/repositorios/oratui/POC/flutter-web)) — ¡Sustituto Interactivo de Grafana con Operación Directa y Login!**:
   Mientras que Grafana únicamente muestra gráficas en modo lectura, la aplicación **Flutter Web** empaquetada en Docker (`oratui-flutter-web`, puerto `:8088`):
   * **Pantalla de Login blindada por `.env`**: Solicita usuario y contraseña definidos en [`POC/.env`](file:///Users/mario/repositorios/oratui/POC/.env) (`FLUTTER_WEB_USER=admin` / `FLUTTER_WEB_PASSWORD=admin` por defecto para la POC) e inyecta automáticamente la cabecera `Authorization: Basic base64(user:pass)` (y `X-OraTui-Token` si se define `ORATUI_API_TOKEN`) en todas las llamadas hacia los servidores Oracle (`:9161`).
   * **Muestra todas las gráficas temporales y barras LCD de alto contraste en tiempo real** (Sesiones vs. Bloqueos TX/TM, CPU vs. RAM, Tablespaces con cálculo automático de `%` real vs. FRA vs. ASM, Errores `ORA-` vs. Caminos SAN Multipath caídos) con estética conmutable *MS-DOS Norton Commander* o *Dark Mode*.
   * **Permite ejecutar acciones correctivas y de mantenimiento directamente sobre los servidores Oracle** (`POST /api/v1/action`) mostrando la salida real de consola (`SQL*Plus`, `RMAN`, `lsnrctl`, `ADRCI`, `multipath`, `sysctl`) en un modal interactivo:
     * **Matar sesiones bloqueantes** (`ALTER SYSTEM KILL SESSION 'sid,serial,@inst' IMMEDIATE`).
     * **Ampliar tablespaces** (`ADD DATAFILE SIZE 32G AUTOEXTEND ON`) y consolidar espacio (`COALESCE`).
     * **Recompilar objetos inválidos** (`UTL_RECOMP.RECOMP_PARALLEL(4)`) y actualizar **estadísticas CBO** (`DBMS_STATS.GATHER_TABLE_STATS`).
     * **Recargar Listeners** (`lsnrctl reload`), forzar `SWITCH LOGFILE` + `CHECKPOINT`, crear **Restore Points Garantizados** (`GRP`), ejecutar **Backup/Crosscheck RMAN de Archivelogs** y **purgar trazas ADRCI** para liberar inodos.
     * **Auditar y recuperar caminos SAN Multipath** (`multipath -ll`, `lsblk`, reescaneo en caliente de buses SCSI/Fibre Channel `/sys/class/scsi_host/host*/scan` + `multipath -r`), auditar `sysctl` y listar el Top 20 de procesos por CPU/RAM.
   * **Incluye un Motor SRE, SLOs (Service Level Objectives) y Avisos Críticos por Telegram y Email SMTP (`GET/POST /api/v1/sre`)**:
     * Calcula en tiempo real **4 SLOs clave** (*Disponibilidad BD & Clusterware 99.95%*, *Operación Libre de Bloqueos TX/TM 99.50%*, *Salud de Capacidad 99.90%* y *Redundancia SAN Multipath 99.99%*), su **SLI actual (%)**, el **Error Budget restante (%)** y la velocidad de consumo (**Burn Rate**).
     * Detecta **Alarmas Delicadas** y ofrece un botón de **remediación en 1 clic** junto a cada alarma.
     * Permite configurar desde la propia web el envío automático o manual de avisos críticos a **Telegram Bot API (`api.telegram.org`)** y **Correo Electrónico SMTP (`STARTTLS` / `AUTH PLAIN`)**, guardando las credenciales con permisos `0600` en `/etc/ora-tui-sre.json` y devolviéndolas enmascaradas (`********`).
   * **Pestaña 7 (`DIAGNÓSTICO AVANZADO & ADVISOR`) + Informe Ejecutivo HTML/PDF (`/api/v1/report`)**:
     * Motor de Recomendaciones Automatizado (**Advisor Engine**), detección de **SQL Plan Flips (`gv$sql`)** con botón para **fijar el mejor plan en SQL Plan Baseline (`DBMS_SPM`)**, progreso en tiempo real de **canales RMAN activos (`gv$session_longops`, `%`, `MB/s`, `ETA`)**, monitorización y relanzado en 1 clic de **Scheduler Jobs de negocio (`dba_scheduler_jobs`)**, latencia de **RAC Cache Fusion (`gc cr/current block receive time`)**, latencia I/O por Datafile (`v$filestat`), salud de **Redo Log Switches/hora & Undo (`ORA-01555`)**, curvas de **Memory Advisor (`SGA`/`PGA`)**, **Wait Chains (`v$wait_chains`)** y degradación de **Parallel Query DOP (`gv$px_session`)**.
     * **3 Paquetes Top inspirados en `OneClickDBA/harry-performance-scraper` (100% libres de licencia AWR/Diagnostics Pack)**:
       1. **Pack 1 — Límites de Recursos (`gv$resource_limit` HWM) & Clases de Espera / AAS (`gv$system_wait_class` + `DB CPU`)**: Previene `ORA-00020` / `ORA-00018` monitorizando el uso actual y el pico histórico (HWM) de `processes`, `sessions`, `dml_locks` y `parallel_max_servers` con botón de dimensionado en 1 clic (`tune_resource_limit` en `SPFILE`), además del desglose porcentual de `DB Time` y `AAS` por clase de espera.
       2. **Pack 2 — Top SQL Consumers por Delta, Percentiles P95/P99 & Visor `DBMS_XPLAN` (`gv$sqlstats`)**: Muestra las sentencias de mayor consumo con su espera dominante (`ON CPU`, `User I/O`, `Application Lock`, `Concurrency`, `Cluster GC`), latencias `Avg`, `P95` y `P99` (ms) y botón en 1 clic **`VER PLAN (DBMS_XPLAN)`** (`explain_sql_plan` vía `DBMS_XPLAN.DISPLAY_CURSOR`).
       3. **Pack 3 — Salud de Destinos Data Guard (`gv$archive_dest_status`) & Autodiagnóstico del Recolector (`CollectorRuntimeHealth`)**: Monitoriza brechas de secuencia de redo (`SeqGap = ArchivedSeq - AppliedSeq`), estado `NO GAP` / `LOG GAP` y antigüedad del dato (`DatumAgeSec`), junto con el presupuesto de latencia de muestreo del propio agente (`LastScrapeDurationMs` / `TimeoutBudgetPct`).
     * Botón **`INFORME HTML/PDF`** en la cabecera superior que abre `/api/v1/report` con un informe ejecutivo completo (incluyendo las 9 secciones técnicas) listo para imprimir o guardar en PDF.

2. **⚡ Arquitectura Daemon Ultra-Ligera (`v1.10.0` — Mínima Memoria RAM y CPU en Servidores Oracle)**:
   * **Conexiones `sqlplus` Agrupadas (`RunSQLPlusBatch`)**: Todas las consultas SQL de cada ciclo se ejecutan en una única sesión `sqlplus -s / as sysdba` con parseo en streaming (`bufio.Scanner`), reduciendo en más de un 90% la creación de procesos sombra en Oracle.
   * **Caché Multicapa (`10s` / `30s` / `60s` / `10m` / `sync.Once`) y Lectura Condicional de `alert_<SID>.log`**: Las vistas pesadas del diccionario (`dba_segments`, `dba_objects`, `dba_data_files`, `dba_scheduler_jobs`) se cachean entre 30s y 60s, `/proc/cpuinfo` se lee una sola vez al arrancar y `alert_<SID>.log` verifica primero `os.Stat` (`size` + `mtime`) para no hacer I/O ni reservar RAM si el fichero no ha cambiado.
   * **Límite de Memoria en Go (`GOMEMLIMIT=48MiB`, `GOGC=50`) y Cgroups en `systemd`**: Tanto `packaging/ora-tui-otel.service` como `POC/ansible/site.yml` configuran `MemoryHigh=48M`, `MemoryMax=96M`, `CPUQuota=15%`, `TasksMax=64` y `Nice=10`.

3. **🔐 Arquitectura de Seguridad entre Flutter Web (`:8088`) y el Servidor Oracle (`:9161`)**:
   * **Lista Blanca Cerrada (`Action Whitelist`)**: El navegador nunca envía comandos SQL ni Bash arbitrarios; solo envía un identificador cerrado (`action: "switch_logfile"`) que el binario Go traduce internamente.
   * **Filtro Estricto Anti-Inyección (`validateSafeTarget`)**: El parámetro `target` se valida contra la expresión regular `^[a-zA-Z0-9_.,@#$+-]{0,96}$`, bloqueando con `HTTP 400` cualquier intento de inyección (`;`, `--`, `DROP`, `UNION`, `` ` ``, `$`).
   * **Autenticación Sincronizada (`HTTP Basic Auth` + `X-OraTui-Token`)**:
     * **Modo POC (por defecto)**: Tanto `POC/.env` como el agente `ora-tui` usan `admin` / `admin`. Al hacer login en Flutter Web, esta envía `Authorization: Basic YWRtaW46YWRtaW4=` y el agente Oracle lo valida automáticamente.
     * **Modo Producción (con Ansible o `.env`)**: Al definir `flutter_web_password` y `oratui_api_token` en [`POC/ansible/inventory.ini`](file:///Users/mario/repositorios/oratui/POC/ansible/inventory.ini), el playbook [`POC/ansible/site.yml`](file:///Users/mario/repositorios/oratui/POC/ansible/site.yml) inyecta automáticamente las mismas credenciales tanto en el servicio `systemd` (`/etc/systemd/system/ora-tui-otel.service`, modo `0600`) de **todos los servidores Oracle** como en el fichero `.env` del contenedor **Flutter Web**.

3. **Prometheus con Autodescubrimiento en Caliente (`file_sd_configs` en `:9090`)**:
   Lee dinámicamente el fichero [`prometheus/targets.yml`](file:///Users/mario/repositorios/oratui/POC/prometheus/targets.yml) cada 15 segundos sin necesidad de reiniciar el contenedor, y evalúa **15 reglas de alarma** críticas ([`prometheus/oracle_alerts.yml`](file:///Users/mario/repositorios/oratui/POC/prometheus/oracle_alerts.yml)).

4. **Grafana Multi-Servidor en 2 Niveles (`:3000`, usuario `admin` / `admin`)**:
   * **Nivel 1 (Home Dashboard) — [`01. Vista Global Multi-Servidor — Flota Oracle & SAN`](file:///Users/mario/repositorios/oratui/POC/grafana/dashboards/oratui_fleet_overview.json)**: Mapa semáforo de todas las máquinas de la flota y rankings `Top 15` con *Drill-Down* en 1 clic.
   * **Nivel 2 (Detalle Completo por Servidor) — [`02. Detalle Completo de Servidor (26 Paneles)`](file:///Users/mario/repositorios/oratui/POC/grafana/dashboards/oratui_full_poc_dashboard.json)**: 26 paneles detallados con filtros jerárquicos encadenados (`Entorno` $\rightarrow$ `Cluster` $\rightarrow$ `Servidor`).

---

## ⚡ Opción A: Configuración Interactiva Rápida con `./configure-poc.sh`

Copia la carpeta `POC/` a tu servidor con Docker y ejecuta:

```bash
cd POC
chmod +x configure-poc.sh start-poc.sh
./configure-poc.sh
```

El script sincroniza automáticamente `prometheus/targets.yml` y `flutter-web/build/web/servers.json`, y levanta los 3 contenedores (`oratui-poc-flutter-web` en `:8088`, `oratui-poc-grafana` en `:3000` y `oratui-poc-prometheus` en `:9090`).

---

## 🤖 Opción B: Despliegue y Sincronización de Seguridad con Ansible (`POC/ansible/`)

En [`POC/ansible/inventory.ini`](file:///Users/mario/repositorios/oratui/POC/ansible/inventory.ini) defines tus servidores y, bajo `[all:vars]`, las credenciales y el token que Ansible repartirá tanto a los demonios Oracle (`systemd`) como a los contenedores Docker (`.env`):

```ini
[all:vars]
flutter_web_user=admin
flutter_web_password=admin
grafana_admin_user=admin
grafana_admin_password=admin
oratui_api_token=
```

Y ejecutas:

```bash
cd POC/ansible
# Instala/actualiza el daemon ora-tui-otel (con sus credenciales/token) en [oracle_servers]
# y despliega Flutter Web (:8088) + Prometheus (:9090) + Grafana (:3000) en [monitoring_server]:
ansible-playbook -i inventory.ini site.yml
```

---

## 🐍 Soporte Híbrido para Flotas con Linux (Go), IBM AIX con Oracle RAC (Python) e IBM i / AS400 (Python)

Cuando tu infraestructura combina servidores **Linux** (donde corre el binario estático en Go) con servidores **IBM AIX ejecutando Oracle Database RAC** o **IBM i (AS/400)** donde solo se permite **Python**, tienes todo integrado en **[`agents/python/`](file:///Users/mario/repositorios/oratui/agents/python/README.md)**:
* **Agente 100% Python 3 Standard Library ([`ora_tui_agent.py`](file:///Users/mario/repositorios/oratui/agents/python/ora_tui_agent.py))**: No requiere `pip` ni compilar extensiones C. En **AIX** autodescubre el cluster **Oracle RAC** (`ocr.loc`, `olsnodes`, `gv$instance`, `gv$session`, `dba_tablespace_usage_metrics`, `v$asm_diskgroup`, `gv$resource_limit` HWM, `gv$system_wait_class` AAS, Top SQL P95/P99 y Data Guard Gaps) junto con LPAR (`lparstat`, `svmon -G`, `lsps -s`) y caminos SAN MPIO (`lspath` / `fcs*`).
* **Uso Interactivo y Daemons Nativos**:
  * **Linux (Go)**: Consola `sudo ora-tui` y daemon `systemd` (`systemctl enable --now ora-tui-otel`).
  * **IBM AIX + Oracle RAC (Python)**: Instalador [`install-aix.sh`](file:///Users/mario/repositorios/oratui/agents/python/install-aix.sh), consola `ora-tui` (`curses`) y daemon nativo **AIX `SRC`** (`startsrc -s oratui`, `lssrc -s oratui`, `/etc/inittab`).
  * **IBM i / AS400 PASE (Python)**: Instalador [`install-ibmi-as400.sh`](file:///Users/mario/repositorios/oratui/agents/python/install-ibmi-as400.sh), consola `/QOpenSys/usr/bin/ora-tui` y daemon batch **`SBMJOB JOB(ORATUI)`** + autoarranque en IPL con **`ADDAJE`**.
* Consulta todos los pasos detallados en **[`agents/python/README.md`](file:///Users/mario/repositorios/oratui/agents/python/README.md)**.

---

## 🏗️ Opción C: Gobierno de Flota con Jenkins ([`Jenkinsfile`](file:///Users/mario/repositorios/oratui/Jenkinsfile))

El [`Jenkinsfile`](file:///Users/mario/repositorios/oratui/Jenkinsfile) incluye parámetros de tipo `password` (`FLUTTER_WEB_PASSWORD` y `ORATUI_API_TOKEN`) para rotar contraseñas y tokens en toda la flota Oracle y en el contenedor Flutter Web con un solo clic. Consulta todos los detalles en **[`POC/jenkins/README.md`](file:///Users/mario/repositorios/oratui/POC/jenkins/README.md)**.
